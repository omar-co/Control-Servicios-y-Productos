<?php

class Record_model extends MY_Model { }