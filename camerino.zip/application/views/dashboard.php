<section id="content">
    <div class="page page-fullwidth-layout">
        <div class="row">
            <div class="col-md-12">
                <div class="pageheader">
                    <h2>Dashboard <span></span></h2>
                </div>
            </div>
        </div>
        <p class="lead">En Construcción.</p>
    </div>
</section>